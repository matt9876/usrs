package com.learnadroid.myfirstapp;

import android.app.ProgressDialog;

import android.content.Intent;

import android.os.AsyncTask;

import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;

import android.view.View;

import android.view.WindowManager;

import android.widget.Button;

import android.widget.EditText;

import android.widget.Toast;


import java.sql.Connection;

import java.sql.ResultSet;

import java.sql.Statement;


public class register extends AppCompatActivity {


    EditText username, pw, email, role;

    Button register;

    ProgressDialog progressDialog;

    ConnectionClass connectionClass;


    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);


        getSupportActionBar().hide();

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,

                WindowManager.LayoutParams.FLAG_FULLSCREEN);


        usermname = (EditText) findViewById(R.id.username);

        pw = (EditText) findViewById(R.id.pw);

        email = (EditText) findViewById(R.id.email);

        role = (EditText) findViewById(R.id.role);

        register = (Button) findViewById(R.id.register);


        connectionClass = new ConnectionClass();


        progressDialog = new ProgressDialog(this);


        register.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {


                Doregister doregister = new Doregister();

                doregister.execute("");

            }

        });


    }


    public class Doregister extends AsyncTask<String, String, String>

    {


        String namestr = username.getText().toString();

        String pwstr = pw.getText().toString();

        String emailstr = email.getText().toString();

        String rolestr = role.getText().toString();

        String z = "";

        boolean isSuccess = false;


        @Override

        protected void onPreExecute() {

            progressDialog.setMessage("Loading...");

            progressDialog.show();

        }


        @Override

        protected String doInBackground(String... params) {


            if (namestr.trim().equals("") || emailstr.trim().equals("") || passstr.trim().equals(""))

                z = "Please enter all fields....";

            else if (role.trim() = !"1" || role.trim() = !"2" || role.trim() = !"3")

                z = "role unknow";


            else

            {

                try {

                    Connection con = connectionClass.CONN();

                    if (con == null) {

                        z = "Please check your internet connection";

                    } else {


                        String query = "insert into ac values('" + namestr + "','" + pwstr + "','" + emailstr + "','" + rolestr + "','')";


                        Statement stmt = con.createStatement();

                        stmt.executeUpdate(query);


                        z = "Register successfull";

                        isSuccess = true;


                    }

                } catch (Exception ex)

                {

                    isSuccess = false;

                    z = "Exceptions" + ex;

                }

            }

            return z;

        }


        @Override

        protected void onPostExecute(String s) {


            Toast.makeText(getBaseContext(), "" + z, Toast.LENGTH_LONG).show();


            if (isSuccess) {

                startActivity(new Intent(register.this, admin.class));


            }


            progressDialog.hide();

        }

    }


}
