package com.learnadroid.myfirstapp;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;

import java.util.Calendar;

public class createMission extends AppCompatActivity {

    TextView tv;
    Calendar startDate;
    int day, month, year;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_mission);
    }

    tv = (TextView) findViewById(R.id.tv);

    startDate = Calendar.getInstance();

    day = startDate.get(Calendar.DAY_OF_MONTH);
    month = startDate.get(Calendar.MONTH);
    year = startDate.get(Calendar.YEAR);

    month = month+1;

        tv.setText(day+"/"+month+"/"+year);

        tv.setOnClickListener(new View.OnClickListener() {

        public void onClick(View v) {
            DatePickerDialog datePickerDialog = new DatePickerDialog(leader.this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    month = month+1;
                    tv.setText(dayOfMonth+"/"+month+"/"+year);
                }
            }, year, month, day);
            datePickerDialog.show();
        }
    });
}
