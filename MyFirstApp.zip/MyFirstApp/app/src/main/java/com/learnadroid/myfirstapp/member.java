package com.learnadroid.myfirstapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class member extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.member_main);
    }
}
