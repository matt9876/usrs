package com.learnadroid.myfirstapp;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONArray;

import java.sql.Array;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

public class Main2Activity extends AppCompatActivity {


    ConnectionClass connectionClass;
    TextView nametext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        connectionClass = new ConnectionClass();
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> lunch = ArrayAdapter.createFromResource(Main2Activity.this, R.array.lunch, android.R.layout.simple_dropdown_item_1line);
        spinner.setAdapter(lunch);
        Connection con = connectionClass.CONN();


        ArrayList<String> array = new ArrayList();
        String name = getIntent().getStringExtra("name");

        nametext = (TextView) findViewById(R.id.name);

        nametext.setText(name);
    }


}
